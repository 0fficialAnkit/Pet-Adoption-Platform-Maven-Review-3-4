package com.adoptionplatform;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class UserServiceTest {

    private UserService userService;
    private UserDAO userDAO;

    @Before
    public void setUp() {
        userDAO = Mockito.mock(UserDAO.class);
        userService = new UserService(userDAO);
    }

    @Test
    public void testRegisterUser() {
        User user = new User("john_doe", "password123", "John Doe", "john@example.com");
        Mockito.when(userDAO.save(user)).thenReturn(true);

        boolean result = userService.registerUser(user);
        assertTrue(result);
    }

    @Test
    public void testAuthenticateUser() {
        Mockito.when(userDAO.findByUsernameAndPassword("john_doe", "password123")).thenReturn(
            new User("john_doe", "password123", "John Doe", "john@example.com")
        );

        boolean result = userService.authenticateUser("john_doe", "password123");
        assertTrue(result);
    }
}
