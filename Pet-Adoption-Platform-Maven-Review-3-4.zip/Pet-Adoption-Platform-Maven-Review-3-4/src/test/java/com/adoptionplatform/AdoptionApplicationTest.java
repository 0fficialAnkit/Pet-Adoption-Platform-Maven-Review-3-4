package com.adoptionplatform;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class AdoptionApplicationTest {

    private AdoptionApplicationService adoptionService;
    private AdoptionApplicationDAO adoptionDAO;

    @Before
    public void setUp() {
        adoptionDAO = Mockito.mock(AdoptionApplicationDAO.class);
        adoptionService = new AdoptionApplicationService(adoptionDAO);
    }

    @Test
    public void testSubmitApplication() {
        AdoptionApplication application = new AdoptionApplication("John Doe", "Buddy", "Dog", "john@example.com");
        Mockito.when(adoptionDAO.save(application)).thenReturn(true);

        boolean result = adoptionService.submitApplication(application);
        assertTrue(result);
    }
}
