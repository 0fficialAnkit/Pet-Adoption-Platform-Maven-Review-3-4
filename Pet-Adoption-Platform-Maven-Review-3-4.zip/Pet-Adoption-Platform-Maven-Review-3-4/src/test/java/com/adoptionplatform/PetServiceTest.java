package com.adoptionplatform;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

public class PetServiceTest {

    private PetService petService;
    private PetDAO petDAO;

    @Before
    public void setUp() {
        petDAO = Mockito.mock(PetDAO.class);
        petService = new PetService(petDAO);
    }

    @Test
    public void testAddPet() {
        Pet pet = new Pet("Buddy", "Dog", "Golden Retriever", 2, "Golden", "Male", true);
        Mockito.when(petDAO.save(pet)).thenReturn(true);

        boolean result = petService.addPet(pet);
        assertTrue(result);
    }

    @Test
    public void testGetAllPets() {
        Mockito.when(petDAO.findAll()).thenReturn(java.util.Arrays.asList(
            new Pet("Buddy", "Dog", "Golden Retriever", 2, "Golden", "Male", true),
            new Pet("Kitty", "Cat", "Persian", 1, "White", "Female", true)
        ));

        assertEquals(2, petService.getAllPets().size());
    }
}
