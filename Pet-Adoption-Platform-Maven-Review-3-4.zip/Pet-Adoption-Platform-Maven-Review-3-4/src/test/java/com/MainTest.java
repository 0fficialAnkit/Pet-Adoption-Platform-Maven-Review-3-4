package com.adoptionplatform;

import com.adoptionplatform.service.UserService;
import org.junit.Test;
import static org.junit.Assert.*;

public class MainTest {
    @Test
    public void testUserRegistration() {
        UserService userService = new UserService();
        boolean result = userService.register("testuser", "password");
        assertTrue(result);
    }

    @Test
    public void testUserAuthentication() {
        UserService userService = new UserService();
        userService.register("testuser", "password");
        assertNotNull(userService.authenticate("testuser", "password"));
    }
}
