// Form Validation
function validateForm(event) {
    const form = event.target;
    const username = form.username.value.trim();
    const password = form.password.value.trim();

    if (username === "" || password === "") {
        alert("All fields are required!");
        event.preventDefault();
        return false;
    }

    if (password.length < 6) {
        alert("Password must be at least 6 characters long!");
        event.preventDefault();
        return false;
    }

    return true;
}

// Attach validation to forms
document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.querySelector('form[action*="auth"]');
    if (loginForm) {
        loginForm.addEventListener('submit', validateForm);
    }
});

// Highlight Selected Pet Row
document.addEventListener('DOMContentLoaded', () => {
    const petRows = document.querySelectorAll('table tbody tr');
    petRows.forEach(row => {
        row.addEventListener('click', () => {
            petRows.forEach(r => r.style.backgroundColor = '');
            row.style.backgroundColor = '#DFF6FF';
        });
    });
});
