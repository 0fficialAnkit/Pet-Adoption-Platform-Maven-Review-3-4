package com.adoptionplatform.service;

import com.adoptionplatform.model.Pet;
import java.util.ArrayList;
import java.util.List;

public class PetService {
    private List<Pet> petDB = new ArrayList<>();

    public List<Pet> getAllPets() {
        return petDB;
    }

    public void addPet(Pet pet) {
        petDB.add(pet);
    }
}
