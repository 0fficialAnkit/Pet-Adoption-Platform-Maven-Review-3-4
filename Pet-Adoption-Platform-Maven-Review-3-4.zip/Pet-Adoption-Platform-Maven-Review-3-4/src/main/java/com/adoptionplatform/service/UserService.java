package com.adoptionplatform.service;

import com.adoptionplatform.model.User;
import java.util.HashMap;
import java.util.Map;

public class UserService {
    private Map<String, String> userDB = new HashMap<>();

    public boolean register(String username, String password) {
        if (!userDB.containsKey(username)) {
            userDB.put(username, password);
            return true;
        }
        return false;
    }

    public User authenticate(String username, String password) {
        if (userDB.containsKey(username) && userDB.get(username).equals(password)) {
            return new User(username, password);
        }
        return null;
    }
}
