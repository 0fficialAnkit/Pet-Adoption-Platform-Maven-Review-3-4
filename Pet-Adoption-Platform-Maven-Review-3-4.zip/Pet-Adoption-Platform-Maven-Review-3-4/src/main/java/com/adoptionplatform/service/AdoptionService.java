package com.adoptionplatform;

public class AdoptionService {
    private AdoptionApplicationDAO adoptionApplicationDAO;

    public AdoptionService() {
        this.adoptionApplicationDAO = new AdoptionApplicationDAO();
    }

    public boolean submitApplication(AdoptionApplication application) {
        return adoptionApplicationDAO.save(application);
    }
}
