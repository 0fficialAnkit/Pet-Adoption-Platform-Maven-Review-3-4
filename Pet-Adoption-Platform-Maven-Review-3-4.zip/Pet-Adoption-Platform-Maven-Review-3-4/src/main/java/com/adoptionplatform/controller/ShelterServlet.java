package com.adoptionplatform;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/shelter")
public class ShelterServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("shelter.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String petName = request.getParameter("petName");
        String petType = request.getParameter("petType");
        String breed = request.getParameter("breed");
        String color = request.getParameter("color");

        Pet pet = new Pet(petName, petType, breed, 1, color, "Unknown", true);
        PetDAO dao = new PetDAO();
        dao.save(pet);

        response.sendRedirect("pet-list.jsp");
    }
}
