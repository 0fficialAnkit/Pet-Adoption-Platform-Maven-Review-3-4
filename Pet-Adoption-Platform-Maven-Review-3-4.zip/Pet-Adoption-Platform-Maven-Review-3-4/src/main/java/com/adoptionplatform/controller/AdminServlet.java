package com.adoptionplatform.controller;

import com.adoptionplatform.model.Pet;
import com.adoptionplatform.service.PetService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/admin")
public class AdminServlet extends HttpServlet {
    private PetService petService;

    @Override
    public void init() throws ServletException {
        petService = new PetService();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Pet> pets = petService.getAllPets();
        request.setAttribute("pets", pets);
        request.getRequestDispatcher("jsp/admin.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("addPet".equals(action)) {
            String name = request.getParameter("name");
            String breed = request.getParameter("breed");
            String age = request.getParameter("age");

            petService.addPet(new Pet(name, breed, Integer.parseInt(age)));
            response.sendRedirect("admin");
        }
    }
}
