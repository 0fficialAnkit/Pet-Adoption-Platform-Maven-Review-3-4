package com.adoptionplatform;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/adopter")
public class AdopterServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("adopter.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String adopterName = request.getParameter("adopterName");
        String petName = request.getParameter("petName");
        String email = request.getParameter("email");

        AdoptionApplication application = new AdoptionApplication(adopterName, petName, "Unknown", email);
        AdoptionApplicationDAO dao = new AdoptionApplicationDAO();
        dao.save(application);

        response.sendRedirect("pet-list.jsp");
    }
}
