package com.adoptionplatform;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AdoptionApplicationDAO {
    private Connection connection;

    public AdoptionApplicationDAO() {
        connection = DatabaseConnection.getConnection();
    }

    public boolean save(AdoptionApplication application) {
        try {
            String query = "INSERT INTO adoption_applications (adopter_name, pet_name, pet_type, email) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setString(1, application.getAdopterName());
            stmt.setString(2, application.getPetName());
            stmt.setString(3, application.getPetType());
            stmt.setString(4, application.getEmail());
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
