package com.adoptionplatform;

public class AdoptionApplication {
    private String adopterName;
    private String petName;
    private String petType;
    private String email;

    public AdoptionApplication(String adopterName, String petName, String petType, String email) {
        this.adopterName = adopterName;
        this.petName = petName;
        this.petType = petType;
        this.email = email;
    }

    public String getAdopterName() { return adopterName; }
    public String getPetName() { return petName; }
    public String getPetType() { return petType; }
    public String getEmail() { return email; }
}
